CASTORE COLLECTION KENYA - WEBSITE DESIGN MOCKUP
================================================

Open the files in any web browser (double-click them).

  index.html                 Homepage design (desktop; resize the window to see tablet/phone)
  all-categories-menu.html   The "All Categories" dropdown menu, open.
                             Hover or click a category on the left to see its subcategories.
  images/                    Photos used in the design

This is a design mockup only. Buttons, search, cart and forms do not work.
Text in [BRACKETS] is a placeholder to fill in later (phone, prices, dates, reviews).

Colours
  Cream background   #F6EFE4      Card / header     #FFFCF7
  Terracotta accent  #A0461F      Dark brown        #3B2A20
  Main text          #2A1F18      Secondary text    #5E4E42
  WhatsApp green     #128C4A

Fonts (free from Google Fonts)
  Headings: Fraunces     Body text: Figtree
